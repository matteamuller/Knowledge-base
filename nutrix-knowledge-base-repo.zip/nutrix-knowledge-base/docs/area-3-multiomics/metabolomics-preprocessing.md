---
title: Metabolomics preprocessing
status: planned
---

# Metabolomics preprocessing

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Peak picking, annotation, missing values
- Normalisation and scaling choices

## Planned worked example

Preprocessing notebook on a mock LC-MS feature table

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
