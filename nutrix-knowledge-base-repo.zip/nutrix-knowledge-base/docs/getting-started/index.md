---
title: Getting started
---

# Getting started

How to read, run, and contribute to the knowledge base.

!!! note "All modules below are planned stubs"
    Scope is defined; content is contributed incrementally.

## Modules

- [Quickstart](quickstart.md) — _planned_
- [Reproducible environments](environments.md) — _planned_
- [How to contribute](how-to-contribute.md) — _planned_
