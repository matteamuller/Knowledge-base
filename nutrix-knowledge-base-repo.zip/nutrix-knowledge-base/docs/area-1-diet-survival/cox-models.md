---
title: Cox proportional-hazards models
status: planned
---

# Cox proportional-hazards models

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Model specification for nutritional exposures
- Proportional-hazards assumption checking
- Reporting hazard ratios responsibly

## Planned worked example

Cox model + `cox.zph` assumption diagnostics

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
