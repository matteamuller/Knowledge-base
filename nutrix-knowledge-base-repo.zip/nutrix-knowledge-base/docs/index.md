---
title: NUTRIx Knowledge Base
---

# NUTRIx Knowledge Base

A living, open-source, version-controlled resource that turns the network's
three thematic areas into concrete, reusable workflows for early-career
nutrition–data scientists.

!!! info "Scaffold stage"
    This repository currently defines the **topic structure**. Each module
    below is a stub with a defined scope; runnable notebooks and guides are
    added collaboratively via merge requests at network Sprint Days.

## Research areas

- **[Area 1 · Dietary Intake & Survival Data](area-1-diet-survival/index.md)**
- **[Area 2 · Reproducible & Transparent ML/AI](area-2-reproducible-ml/index.md)**
- **[Area 3 · Multi-omics Data Integration](area-3-multiomics/index.md)**
- **[Foundations](foundations/index.md)** — FAIR, reproducibility, governance

See **[Getting started](getting-started/quickstart.md)** to run or contribute.
