---
title: Foundations (cross-cutting)
---

# Foundations (cross-cutting)

The FAIR, reproducibility, and governance layer every module depends on.

!!! note "All modules below are planned stubs"
    Scope is defined; content is contributed incrementally.

## Modules

- [FAIR data management](fair-data-management.md) — _planned_
- [Metadata & NFDI4Health schema](metadata-nfdi4health.md) — _planned_
- [Data governance & ethics](data-governance-ethics.md) — _planned_
- [Containerisation](containerisation.md) — _planned_
- [Archiving & DOIs (Zenodo)](archiving-zenodo.md) — _planned_
- [Glossary](glossary.md) — _planned_
