---
title: Image-based assessment models
status: planned
---

# Image-based assessment models

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- When (not) to use deep learning in nutrition
- Food-image recognition for dietary assessment

## Planned worked example

Evaluation harness for a food-image model

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
