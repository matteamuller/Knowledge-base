---
title: Differential abundance with covariates
status: planned
---

# Differential abundance with covariates

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Covariate-adjusted association testing
- MaAsLin-style models

## Planned worked example

Diet-adjusted differential-abundance analysis

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
