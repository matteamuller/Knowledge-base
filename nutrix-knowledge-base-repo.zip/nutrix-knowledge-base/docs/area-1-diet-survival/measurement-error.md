---
title: Measurement error & calibration
status: planned
---

# Measurement error & calibration

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Random vs systematic dietary measurement error
- Regression calibration with a biomarker sub-study
- Impact on effect estimates

## Planned worked example

Regression-calibration demo with a calibration sub-sample

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
