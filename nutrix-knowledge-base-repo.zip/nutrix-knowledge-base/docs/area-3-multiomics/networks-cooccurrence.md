---
title: Co-occurrence & correlation networks
status: planned
---

# Co-occurrence & correlation networks

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Building and interpreting microbial/metabolite networks
- Spurious-correlation pitfalls in compositional data

## Planned worked example

Sparse correlation network from a mock dataset

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
