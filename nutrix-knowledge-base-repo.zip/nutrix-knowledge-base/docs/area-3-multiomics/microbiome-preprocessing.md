---
title: Microbiome preprocessing
status: planned
---

# Microbiome preprocessing

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Normalisation and the rarefaction debate
- Compositionality and the CLR transform
- Quality control

## Planned worked example

CLR pipeline on a mock microbiome count table

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
