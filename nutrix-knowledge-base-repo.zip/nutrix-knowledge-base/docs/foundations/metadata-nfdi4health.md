---
title: Metadata & NFDI4Health schema
status: planned
---

# Metadata & NFDI4Health schema

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Foundations (cross-cutting)._

## Scope

- Aligning module metadata to the NFDI4Health schema
- Minimal metadata every dataset carries

## Planned worked example

Metadata record validated against the schema

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
