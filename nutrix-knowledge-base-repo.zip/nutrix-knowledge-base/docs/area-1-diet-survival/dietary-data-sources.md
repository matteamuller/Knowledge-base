---
title: Dietary data sources & instruments
status: planned
---

# Dietary data sources & instruments

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- FFQs, 24-h recalls, food records, weighed diaries
- Strengths, biases, and intended analytical use of each
- Worked orientation on the NVS II structure

## Planned worked example

Side-by-side comparison of recall vs FFQ data on a shared mock dataset

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
