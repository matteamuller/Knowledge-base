---
title: Archiving & DOIs (Zenodo)
status: planned
---

# Archiving & DOIs (Zenodo)

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Foundations (cross-cutting)._

## Scope

- Tag-to-Zenodo release flow
- Per-module citation blocks

## Planned worked example

Release workflow that mints a DOI on tag

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
