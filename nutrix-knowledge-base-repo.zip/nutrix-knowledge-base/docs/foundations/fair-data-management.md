---
title: FAIR data management
status: planned
---

# FAIR data management

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Foundations (cross-cutting)._

## Scope

- Findable / Accessible / Interoperable / Reusable in practice
- How each module satisfies FAIR

## Planned worked example

FAIR self-assessment template for a module

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
