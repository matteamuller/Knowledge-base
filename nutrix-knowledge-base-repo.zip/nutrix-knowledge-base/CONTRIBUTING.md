# Contributing

The contribution model *is* the sustainability model: using the resource
and improving it are the same action.

## Workflow

1. Open an issue describing the module / fix (use the area label).
2. Branch from `main`: `git checkout -b area-1/causal-dags`.
3. Fill the module stub following the template (see any `*.md` under
   `docs/`): keep the front-matter, update `status:` from `planned` to
   `draft` then `stable`.
4. Add runnable code under the module folder with a pinned environment.
5. Open a merge request; a **peer tandem** reviews before merge.

## Module template

Each module keeps: YAML front-matter, a status admonition, a `## Scope`
section, a `## Planned worked example` (becomes the actual example), and a
`## Lead & contributors` block.

## Status values

`planned` → scope only · `draft` → example works, under review ·
`stable` → reviewed and released.
