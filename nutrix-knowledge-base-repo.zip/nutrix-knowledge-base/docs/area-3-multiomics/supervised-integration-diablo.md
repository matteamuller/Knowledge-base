---
title: Supervised integration (DIABLO)
status: planned
---

# Supervised integration (DIABLO)

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Outcome-driven multiblock modelling
- Multiblock PLS / mixOmics

## Planned worked example

DIABLO model linking omics blocks to a phenotype

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
