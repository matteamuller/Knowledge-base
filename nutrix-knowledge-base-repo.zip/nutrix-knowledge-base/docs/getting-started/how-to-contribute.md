---
title: How to contribute
status: planned
---

# How to contribute

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Getting started._

## Scope

- Branch / merge-request workflow used at Sprint Days
- Peer-tandem review before merge
- Module template and style guide

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
