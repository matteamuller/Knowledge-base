---
title: Interpretable ML for survival
status: planned
---

# Interpretable ML for survival

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Global vs local, model-agnostic explanations
- Time-dependent feature importance, ALE/PDP over time
- Censoring-aware interpretation pitfalls

## Planned worked example

Model-agnostic explanations for an RSF (survex-style)

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
