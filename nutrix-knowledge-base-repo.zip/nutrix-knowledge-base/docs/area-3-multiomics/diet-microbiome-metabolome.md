---
title: Diet–microbiome–metabolome links
status: planned
---

# Diet–microbiome–metabolome links

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Linking dietary intake to omics layers
- Mediation in an omics context

## Planned worked example

Diet → microbiome → metabolite mediation example

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
