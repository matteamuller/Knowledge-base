---
title: Reproducible omics pipelines
status: planned
---

# Reproducible omics pipelines

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Galaxy workflows and containerised bioinformatics
- Provenance and metadata for omics

## Planned worked example

Galaxy / containerised end-to-end omics pipeline

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
