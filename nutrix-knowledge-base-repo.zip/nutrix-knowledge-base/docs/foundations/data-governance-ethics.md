---
title: Data governance & ethics
status: planned
---

# Data governance & ethics

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Foundations (cross-cutting)._

## Scope

- Privacy and IT-security in dietary data reuse
- Consent, access tiers, and SUF handling

## Planned worked example

Governance checklist for sharing a derived dataset

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
