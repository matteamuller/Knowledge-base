#!/usr/bin/env python3
"""Scaffold the NUTRIx Knowledge Base GitHub repository.

Single source of truth: TAXONOMY drives the docs tree, the per-area
index pages, and the mkdocs nav. Every topic gets a *stub* (scope
outline + 'planned' status) — no tutorial content is written yet.
"""
import os, textwrap, json

ROOT = "/home/claude/nutrix-knowledge-base"
DOCS = os.path.join(ROOT, "docs")

# (slug, Title, [scope bullets], "planned worked example")
TAXONOMY = {
    "getting-started": {
        "title": "Getting started",
        "blurb": "How to read, run, and contribute to the knowledge base.",
        "topics": [
            ("quickstart", "Quickstart",
             ["Clone the repository and build the site locally",
              "Run a notebook in the pinned container",
              "Repository layout and where things live"],
             "n/a — orientation page"),
            ("environments", "Reproducible environments",
             ["conda / `environment.yml` for Python modules",
              "`renv` for R modules",
              "One-line container command (Docker / Apptainer)"],
             "Minimal `environment.yml` + `renv.lock` template that all modules inherit"),
            ("how-to-contribute", "How to contribute",
             ["Branch / merge-request workflow used at Sprint Days",
              "Peer-tandem review before merge",
              "Module template and style guide"],
             "n/a — process page"),
        ],
    },
    "area-1-diet-survival": {
        "title": "Area 1 · Dietary Intake & Survival Data",
        "blurb": "Dietary assessment data and interpretable survival analysis in nutritional cohorts.",
        "topics": [
            ("dietary-data-sources", "Dietary data sources & instruments",
             ["FFQs, 24-h recalls, food records, weighed diaries",
              "Strengths, biases, and intended analytical use of each",
              "Worked orientation on the NVS II structure"],
             "Side-by-side comparison of recall vs FFQ data on a shared mock dataset"),
            ("digital-dietary-assessment", "Digital & app-based dietary assessment",
             ["App-based and image-based food records",
              "Validation against reference methods",
              "Harmonising digital output for downstream analysis"],
             "Pipeline converting app export → analysis-ready intake table"),
            ("food-composition-databases", "Food composition & branded-food databases",
             ["Mapping reported foods to composition databases",
              "Branded-food database structure and enrichment",
              "LLM-supported label parsing pipelines"],
             "Notebook matching free-text food entries to a composition database"),
            ("dietary-data-preprocessing", "Preprocessing & harmonisation",
             ["Energy adjustment (residual / density methods)",
              "Implausible energy-intake handling",
              "Diet-quality score construction",
              "Compositional nature of intake data"],
             "End-to-end cleaning notebook on simulated NVS II-style data"),
            ("measurement-error", "Measurement error & calibration",
             ["Random vs systematic dietary measurement error",
              "Regression calibration with a biomarker sub-study",
              "Impact on effect estimates"],
             "Regression-calibration demo with a calibration sub-sample"),
            ("dietary-patterns", "Dietary patterns",
             ["A priori indices vs a posteriori (PCA / factor / cluster)",
              "Reduced-rank regression",
              "ML-based pattern derivation and stability"],
             "Comparison of PCA-derived vs index-based patterns"),
            ("causal-dags", "Causal DAGs",
             ["Reading and building DAGs (dagitty / ggdag)",
              "Minimal sufficient adjustment sets",
              "Documenting edge justifications from the literature"],
             "Diet-pattern → CVD DAG with derived adjustment set"),
            ("confounders-mediators-colliders", "Confounders, mediators & colliders",
             ["Distinguishing the three structurally",
              "Why 'adjust for everything' is wrong",
              "Total vs direct effects"],
             "Bias demonstration: adjusting for a mediator vs not"),
            ("sensitivity-analysis", "Sensitivity & bias analysis",
             ["Unmeasured confounding (E-value)",
              "Selection bias and missing-data DAGs",
              "Quantitative bias analysis templates"],
             "E-value computation for a published nutrition association"),
            ("survival-basics", "Survival analysis basics",
             ["Time-to-event data, censoring, time scale choice",
              "Kaplan–Meier and the log-rank test"],
             "KM curves by dietary-pattern tertile on a mock cohort"),
            ("cox-models", "Cox proportional-hazards models",
             ["Model specification for nutritional exposures",
              "Proportional-hazards assumption checking",
              "Reporting hazard ratios responsibly"],
             "Cox model + `cox.zph` assumption diagnostics"),
            ("competing-risks-time-varying", "Competing risks & time-varying exposures",
             ["Cause-specific vs subdistribution hazards",
              "Time-varying covariates and exposures"],
             "Competing-risks analysis with a non-cardiovascular death risk"),
            ("random-survival-forests", "Random survival forests",
             ["Non-linear survival benchmarking",
              "Variable importance for time-to-event outcomes"],
             "RSF benchmark against the Cox model on the same cohort"),
            ("interpretable-ml-survival", "Interpretable ML for survival",
             ["Global vs local, model-agnostic explanations",
              "Time-dependent feature importance, ALE/PDP over time",
              "Censoring-aware interpretation pitfalls"],
             "Model-agnostic explanations for an RSF (survex-style)"),
            ("cohort-workflow-example", "End-to-end cohort workflow",
             ["From raw cohort extract to reproducible result",
              "Codebook / data dictionary practice"],
             "Containerised UK Biobank / NVS II-style worked example"),
        ],
    },
    "area-2-reproducible-ml": {
        "title": "Area 2 · Reproducible & Transparent ML/AI",
        "blurb": "Leakage-safe, uncertainty-aware, FAIR machine learning for nutrition data.",
        "topics": [
            ("ml-fundamentals", "ML fundamentals for nutrition researchers",
             ["Supervised vs unsupervised framing",
              "Train/validation/test, cross-validation, nested CV",
              "Regularisation and tree ensembles"],
             "Annotated baseline classification pipeline on nutrition data"),
            ("data-leakage", "Avoiding data leakage",
             ["Preprocessing, temporal, and group leakage",
              "Putting transforms inside the CV pipeline"],
             "Leakage-safe scaling + feature-selection pipeline"),
            ("small-sample-overfitting", "Small samples & overfitting",
             ["Why nutrition cohorts are leakage- and overfit-prone",
              "Sample-size effects on stability",
              "Class imbalance handling"],
             "Learning-curve and stability simulation by sample size"),
            ("uncertainty-quantification", "Uncertainty quantification",
             ["Reporting variability, not a single metric",
              "Bootstrap / repeated resampling",
              "Probability calibration"],
             "Repeated-CV AUC with confidence intervals and calibration plot"),
            ("feature-selection-stability", "Feature-selection stability",
             ["Stability metrics across resamples",
              "Interpreting unstable 'important nutrients'"],
             "Stability index across bootstrap feature-selection runs"),
            ("interpretable-ml", "Interpretable / explainable ML",
             ["Global vs local, model-specific vs agnostic taxonomy",
              "Permutation & conditional importance, SHAP, PDP/ICE/ALE",
              "Correlated-feature pitfalls (relevant to nutrients)"],
             "SHAP vs permutation importance under correlated intake variables"),
            ("environments-containers", "Environments & containers",
             ["conda / renv pinning",
              "Docker / Apptainer for analysis reproducibility"],
             "Container that reproduces a module bit-for-bit"),
            ("workflow-managers", "Workflow managers",
             ["When to move from scripts to a workflow manager",
              "Snakemake / Nextflow / targets for analysis pipelines"],
             "Minimal Snakemake workflow for a modelling pipeline"),
            ("reporting-standards", "Reporting standards & checklists",
             ["Domain-specific ML reporting checklist",
              "Model cards / datasheets for nutrition models"],
             "Filled reporting checklist for an example study"),
            ("fairness-ethics-ai", "Fairness & ethics in nutrition AI",
             ["Bias and subgroup performance",
              "Privacy and governance of dietary data",
              "Responsible deployment considerations"],
             "Subgroup performance audit of a nutrition classifier"),
            ("image-based-assessment-models", "Image-based assessment models",
             ["When (not) to use deep learning in nutrition",
              "Food-image recognition for dietary assessment"],
             "Evaluation harness for a food-image model"),
            ("llm-food-data", "LLMs for food-data parsing",
             ["LLM-supported label / free-text parsing",
              "Validation and failure-mode auditing"],
             "Structured extraction from free-text food entries with evaluation"),
        ],
    },
    "area-3-multiomics": {
        "title": "Area 3 · Multi-omics Data Integration",
        "blurb": "Harmonisation and integrative modelling of diet, microbiome, and metabolome.",
        "topics": [
            ("omics-data-types", "Omics data-type primer",
             ["Microbiome (16S / shotgun), metabolomics (LC-MS / NMR)",
              "Proteomics, transcriptomics, genomics at a glance",
              "Formats and standards per layer"],
             "Annotated tour of one example dataset per omic layer"),
            ("microbiome-preprocessing", "Microbiome preprocessing",
             ["Normalisation and the rarefaction debate",
              "Compositionality and the CLR transform",
              "Quality control"],
             "CLR pipeline on a mock microbiome count table"),
            ("metabolomics-preprocessing", "Metabolomics preprocessing",
             ["Peak picking, annotation, missing values",
              "Normalisation and scaling choices"],
             "Preprocessing notebook on a mock LC-MS feature table"),
            ("batch-effects", "Batch effects",
             ["Detecting batch structure",
              "Correction (ComBat-style) and its risks"],
             "Before/after batch-correction diagnostic"),
            ("dimensionality-reduction", "Dimensionality reduction",
             ["PCA / PCoA and UMAP/t-SNE caveats",
              "Feature selection for high-dimensional omics"],
             "Ordination comparison on an integrated dataset"),
            ("unsupervised-integration-mofa", "Unsupervised integration (MOFA2)",
             ["Latent-factor multi-omics models",
              "Variance decomposition across layers"],
             "MOFA2 integration of diet + microbiome + metabolome"),
            ("supervised-integration-diablo", "Supervised integration (DIABLO)",
             ["Outcome-driven multiblock modelling",
              "Multiblock PLS / mixOmics"],
             "DIABLO model linking omics blocks to a phenotype"),
            ("differential-abundance", "Differential abundance with covariates",
             ["Covariate-adjusted association testing",
              "MaAsLin-style models"],
             "Diet-adjusted differential-abundance analysis"),
            ("networks-cooccurrence", "Co-occurrence & correlation networks",
             ["Building and interpreting microbial/metabolite networks",
              "Spurious-correlation pitfalls in compositional data"],
             "Sparse correlation network from a mock dataset"),
            ("diet-microbiome-metabolome", "Diet–microbiome–metabolome links",
             ["Linking dietary intake to omics layers",
              "Mediation in an omics context"],
             "Diet → microbiome → metabolite mediation example"),
            ("pathway-enrichment", "Pathway enrichment & interpretation",
             ["From features to biology",
              "Enrichment methods and over-interpretation risks"],
             "Enrichment on a set of diet-associated metabolites"),
            ("reproducible-omics-pipelines", "Reproducible omics pipelines",
             ["Galaxy workflows and containerised bioinformatics",
              "Provenance and metadata for omics"],
             "Galaxy / containerised end-to-end omics pipeline"),
        ],
    },
    "foundations": {
        "title": "Foundations (cross-cutting)",
        "blurb": "The FAIR, reproducibility, and governance layer every module depends on.",
        "topics": [
            ("fair-data-management", "FAIR data management",
             ["Findable / Accessible / Interoperable / Reusable in practice",
              "How each module satisfies FAIR"],
             "FAIR self-assessment template for a module"),
            ("metadata-nfdi4health", "Metadata & NFDI4Health schema",
             ["Aligning module metadata to the NFDI4Health schema",
              "Minimal metadata every dataset carries"],
             "Metadata record validated against the schema"),
            ("data-governance-ethics", "Data governance & ethics",
             ["Privacy and IT-security in dietary data reuse",
              "Consent, access tiers, and SUF handling"],
             "Governance checklist for sharing a derived dataset"),
            ("containerisation", "Containerisation",
             ["One container, every module",
              "Docker / Apptainer patterns for research"],
             "Base image inherited by all modules"),
            ("archiving-zenodo", "Archiving & DOIs (Zenodo)",
             ["Tag-to-Zenodo release flow",
              "Per-module citation blocks"],
             "Release workflow that mints a DOI on tag"),
            ("glossary", "Glossary",
             ["Shared definitions across the three areas"],
             "n/a — reference page"),
        ],
    },
}

STATUS_BANNER = ('!!! note "Status: planned"\n'
                 '    This module is **scaffolded but not yet written**. '
                 'The outline below defines its intended scope and the worked '
                 'example it will ship with. Content is added via merge request '
                 'at network Sprint Days.\n')


def w(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content.rstrip() + "\n")


def stub(area_title, title, scope, example):
    bullets = "\n".join(f"- {s}" for s in scope)
    ex = "" if example.startswith("n/a") else (
        f"\n## Planned worked example\n\n{example}\n")
    return (f"---\ntitle: {title}\nstatus: planned\n---\n\n"
            f"# {title}\n\n{STATUS_BANNER}\n"
            f"_Part of {area_title}._\n\n"
            f"## Scope\n\n{bullets}\n{ex}\n"
            f"## Lead & contributors\n\n_To be assigned at network recruitment / Sprint Day._\n")


# ---- docs/index.md ----
w(os.path.join(DOCS, "index.md"), textwrap.dedent("""\
    ---
    title: NUTRIx Knowledge Base
    ---

    # NUTRIx Knowledge Base

    A living, open-source, version-controlled resource that turns the network's
    three thematic areas into concrete, reusable workflows for early-career
    nutrition–data scientists.

    !!! info "Scaffold stage"
        This repository currently defines the **topic structure**. Each module
        below is a stub with a defined scope; runnable notebooks and guides are
        added collaboratively via merge requests at network Sprint Days.

    ## Research areas

    - **[Area 1 · Dietary Intake & Survival Data](area-1-diet-survival/index.md)**
    - **[Area 2 · Reproducible & Transparent ML/AI](area-2-reproducible-ml/index.md)**
    - **[Area 3 · Multi-omics Data Integration](area-3-multiomics/index.md)**
    - **[Foundations](foundations/index.md)** — FAIR, reproducibility, governance

    See **[Getting started](getting-started/quickstart.md)** to run or contribute.
    """))

# ---- per-area index + topic stubs + collect nav ----
nav_lines = []
nav_lines.append("  - Home: index.md")

for slug, area in TAXONOMY.items():
    topics = area["topics"]
    # area index
    listing = "\n".join(f"- [{ttitle}]({tslug}.md) — _planned_"
                         for tslug, ttitle, *_ in topics)
    w(os.path.join(DOCS, slug, "index.md"),
      f"---\ntitle: {area['title']}\n---\n\n# {area['title']}\n\n"
      f"{area['blurb']}\n\n"
      f'!!! note "All modules below are planned stubs"\n'
      f"    Scope is defined; content is contributed incrementally.\n\n"
      f"## Modules\n\n{listing}\n")
    # stubs
    for tslug, ttitle, scope, example in topics:
        w(os.path.join(DOCS, slug, f"{tslug}.md"),
          stub(area["title"], ttitle, scope, example))
    # nav
    nav_lines.append(f"  - {area['title']}:")
    nav_lines.append(f"      - Overview: {slug}/index.md")
    for tslug, ttitle, *_ in topics:
        nav_lines.append(f"      - {ttitle}: {slug}/{tslug}.md")

nav_block = "\n".join(nav_lines)

# ---- mkdocs.yml (plain string; nav must not be dedented) ----
mkdocs_yml = (
    "site_name: NUTRIx Knowledge Base\n"
    "site_description: Open-source knowledge base for the NUTRIx Network for Computational Nutrition Science\n"
    "site_url: https://nutrix-network.github.io/knowledge-base/\n"
    "repo_url: https://github.com/nutrix-network/knowledge-base\n"
    "repo_name: nutrix-network/knowledge-base\n"
    "edit_uri: edit/main/docs/\n\n"
    "theme:\n"
    "  name: material\n"
    "  palette:\n"
    "    - scheme: default\n"
    "      primary: green\n"
    "      accent: deep orange\n"
    "  features:\n"
    "    - navigation.sections\n"
    "    - navigation.top\n"
    "    - navigation.indexes\n"
    "    - content.code.copy\n"
    "    - content.action.edit\n"
    "    - search.suggest\n\n"
    "markdown_extensions:\n"
    "  - admonition\n"
    "  - attr_list\n"
    "  - tables\n"
    "  - toc:\n"
    "      permalink: true\n"
    "  - pymdownx.highlight\n"
    "  - pymdownx.superfences\n\n"
    "plugins:\n"
    "  - search\n\n"
    "nav:\n" + nav_block + "\n"
)
w(os.path.join(ROOT, "mkdocs.yml"), mkdocs_yml)

# ---- README ----
w(os.path.join(ROOT, "README.md"), textwrap.dedent("""\
    # NUTRIx Knowledge Base

    The open-source, version-controlled knowledge base of the **NUTRIx Network
    for Computational Nutrition Science**. It turns the network's three thematic
    areas into concrete, reusable workflows — annotated notebooks, reproducible
    pipelines, and best-practice guides — for early-career nutrition–data
    scientists.

    > **Status: scaffold.** This repository currently defines the *topic
    > structure* across the three research areas plus a cross-cutting
    > Foundations section. Each module is a stub with a defined scope; runnable
    > content is contributed incrementally via merge requests at network
    > Sprint Days.

    ## Structure

    | Area | Folder |
    |---|---|
    | Dietary Intake & Survival Data | `docs/area-1-diet-survival/` |
    | Reproducible & Transparent ML/AI | `docs/area-2-reproducible-ml/` |
    | Multi-omics Data Integration | `docs/area-3-multiomics/` |
    | Foundations (FAIR, reproducibility, governance) | `docs/foundations/` |

    ## Build the site locally

    ```bash
    pip install mkdocs-material
    mkdocs serve        # http://127.0.0.1:8000
    ```

    A push to `main` builds and deploys the site to GitHub Pages automatically
    (see `.github/workflows/deploy.yml`).

    ## Publish on GitHub

    ```bash
    git init
    git add .
    git commit -m "Scaffold NUTRIx Knowledge Base (topic structure)"
    git branch -M main
    git remote add origin https://github.com/<org>/knowledge-base.git
    git push -u origin main
    ```

    Then enable **Settings → Pages → Source: GitHub Actions**.

    ## Contributing

    See [`CONTRIBUTING.md`](CONTRIBUTING.md). Every module follows the same
    template; changes are reviewed by a peer tandem before merge.

    ## Licence

    Code: **MIT** (`LICENSE`). Educational/written content: **CC-BY 4.0**.
    Tagged releases are archived to **Zenodo** with a citable DOI.
    """))

# ---- CONTRIBUTING ----
w(os.path.join(ROOT, "CONTRIBUTING.md"), textwrap.dedent("""\
    # Contributing

    The contribution model *is* the sustainability model: using the resource
    and improving it are the same action.

    ## Workflow

    1. Open an issue describing the module / fix (use the area label).
    2. Branch from `main`: `git checkout -b area-1/causal-dags`.
    3. Fill the module stub following the template (see any `*.md` under
       `docs/`): keep the front-matter, update `status:` from `planned` to
       `draft` then `stable`.
    4. Add runnable code under the module folder with a pinned environment.
    5. Open a merge request; a **peer tandem** reviews before merge.

    ## Module template

    Each module keeps: YAML front-matter, a status admonition, a `## Scope`
    section, a `## Planned worked example` (becomes the actual example), and a
    `## Lead & contributors` block.

    ## Status values

    `planned` → scope only · `draft` → example works, under review ·
    `stable` → reviewed and released.
    """))

# ---- LICENSE (MIT) ----
w(os.path.join(ROOT, "LICENSE"), textwrap.dedent("""\
    MIT License

    Copyright (c) 2026 NUTRIx Network for Computational Nutrition Science

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE. Written/educational content is additionally licensed CC-BY 4.0.
    """))

# ---- GitHub Actions: build + deploy to Pages ----
w(os.path.join(ROOT, ".github", "workflows", "deploy.yml"), textwrap.dedent("""\
    name: Deploy knowledge base

    on:
      push:
        branches: [main]
      workflow_dispatch:

    permissions:
      contents: read
      pages: write
      id-token: write

    jobs:
      build:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - uses: actions/setup-python@v5
            with:
              python-version: "3.12"
          - run: pip install mkdocs-material
          - run: mkdocs build --strict
          - uses: actions/upload-pages-artifact@v3
            with:
              path: site

      deploy:
        needs: build
        runs-on: ubuntu-latest
        environment:
          name: github-pages
          url: ${{ steps.deployment.outputs.page_url }}
        steps:
          - id: deployment
            uses: actions/deploy-pages@v4
    """))

# ---- env + gitignore ----
w(os.path.join(ROOT, "environment.yml"), textwrap.dedent("""\
    # Base environment inherited by Python modules. Module-specific
    # dependencies are pinned in each module folder.
    name: nutrix-kb
    channels: [conda-forge]
    dependencies:
      - python=3.12
      - jupyterlab
      - numpy
      - pandas
      - scikit-learn
      - pip
    """))

w(os.path.join(ROOT, ".gitignore"), textwrap.dedent("""\
    site/
    .ipynb_checkpoints/
    __pycache__/
    .venv/
    *.pyc
    .DS_Store
    """))

print("Repository scaffolded at", ROOT)
