---
title: Uncertainty quantification
status: planned
---

# Uncertainty quantification

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- Reporting variability, not a single metric
- Bootstrap / repeated resampling
- Probability calibration

## Planned worked example

Repeated-CV AUC with confidence intervals and calibration plot

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
