---
title: Dietary patterns
status: planned
---

# Dietary patterns

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- A priori indices vs a posteriori (PCA / factor / cluster)
- Reduced-rank regression
- ML-based pattern derivation and stability

## Planned worked example

Comparison of PCA-derived vs index-based patterns

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
