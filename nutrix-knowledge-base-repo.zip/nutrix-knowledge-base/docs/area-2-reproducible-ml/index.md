---
title: Area 2 · Reproducible & Transparent ML/AI
---

# Area 2 · Reproducible & Transparent ML/AI

Leakage-safe, uncertainty-aware, FAIR machine learning for nutrition data.

!!! note "All modules below are planned stubs"
    Scope is defined; content is contributed incrementally.

## Modules

- [ML fundamentals for nutrition researchers](ml-fundamentals.md) — _planned_
- [Avoiding data leakage](data-leakage.md) — _planned_
- [Small samples & overfitting](small-sample-overfitting.md) — _planned_
- [Uncertainty quantification](uncertainty-quantification.md) — _planned_
- [Feature-selection stability](feature-selection-stability.md) — _planned_
- [Interpretable / explainable ML](interpretable-ml.md) — _planned_
- [Environments & containers](environments-containers.md) — _planned_
- [Workflow managers](workflow-managers.md) — _planned_
- [Reporting standards & checklists](reporting-standards.md) — _planned_
- [Fairness & ethics in nutrition AI](fairness-ethics-ai.md) — _planned_
- [Image-based assessment models](image-based-assessment-models.md) — _planned_
- [LLMs for food-data parsing](llm-food-data.md) — _planned_
