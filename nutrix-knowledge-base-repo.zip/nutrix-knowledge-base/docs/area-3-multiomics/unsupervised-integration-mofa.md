---
title: Unsupervised integration (MOFA2)
status: planned
---

# Unsupervised integration (MOFA2)

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Latent-factor multi-omics models
- Variance decomposition across layers

## Planned worked example

MOFA2 integration of diet + microbiome + metabolome

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
