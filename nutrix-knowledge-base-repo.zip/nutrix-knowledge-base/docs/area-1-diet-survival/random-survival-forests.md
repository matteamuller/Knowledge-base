---
title: Random survival forests
status: planned
---

# Random survival forests

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Non-linear survival benchmarking
- Variable importance for time-to-event outcomes

## Planned worked example

RSF benchmark against the Cox model on the same cohort

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
