---
title: Sensitivity & bias analysis
status: planned
---

# Sensitivity & bias analysis

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Unmeasured confounding (E-value)
- Selection bias and missing-data DAGs
- Quantitative bias analysis templates

## Planned worked example

E-value computation for a published nutrition association

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
