---
title: Preprocessing & harmonisation
status: planned
---

# Preprocessing & harmonisation

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Energy adjustment (residual / density methods)
- Implausible energy-intake handling
- Diet-quality score construction
- Compositional nature of intake data

## Planned worked example

End-to-end cleaning notebook on simulated NVS II-style data

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
