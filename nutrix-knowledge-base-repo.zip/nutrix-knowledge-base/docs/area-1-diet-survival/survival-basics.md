---
title: Survival analysis basics
status: planned
---

# Survival analysis basics

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Time-to-event data, censoring, time scale choice
- Kaplan–Meier and the log-rank test

## Planned worked example

KM curves by dietary-pattern tertile on a mock cohort

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
