---
title: Omics data-type primer
status: planned
---

# Omics data-type primer

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 3 · Multi-omics Data Integration._

## Scope

- Microbiome (16S / shotgun), metabolomics (LC-MS / NMR)
- Proteomics, transcriptomics, genomics at a glance
- Formats and standards per layer

## Planned worked example

Annotated tour of one example dataset per omic layer

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
