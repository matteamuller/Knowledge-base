---
title: End-to-end cohort workflow
status: planned
---

# End-to-end cohort workflow

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- From raw cohort extract to reproducible result
- Codebook / data dictionary practice

## Planned worked example

Containerised UK Biobank / NVS II-style worked example

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
