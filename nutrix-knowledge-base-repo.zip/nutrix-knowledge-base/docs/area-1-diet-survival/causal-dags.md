---
title: Causal DAGs
status: planned
---

# Causal DAGs

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Reading and building DAGs (dagitty / ggdag)
- Minimal sufficient adjustment sets
- Documenting edge justifications from the literature

## Planned worked example

Diet-pattern → CVD DAG with derived adjustment set

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
