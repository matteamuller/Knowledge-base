---
title: Quickstart
status: planned
---

# Quickstart

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Getting started._

## Scope

- Clone the repository and build the site locally
- Run a notebook in the pinned container
- Repository layout and where things live

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
