---
title: Reproducible environments
status: planned
---

# Reproducible environments

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Getting started._

## Scope

- conda / `environment.yml` for Python modules
- `renv` for R modules
- One-line container command (Docker / Apptainer)

## Planned worked example

Minimal `environment.yml` + `renv.lock` template that all modules inherit

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
