---
title: Glossary
status: planned
---

# Glossary

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Foundations (cross-cutting)._

## Scope

- Shared definitions across the three areas

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
