---
title: Digital & app-based dietary assessment
status: planned
---

# Digital & app-based dietary assessment

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- App-based and image-based food records
- Validation against reference methods
- Harmonising digital output for downstream analysis

## Planned worked example

Pipeline converting app export → analysis-ready intake table

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
