---
title: ML fundamentals for nutrition researchers
status: planned
---

# ML fundamentals for nutrition researchers

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- Supervised vs unsupervised framing
- Train/validation/test, cross-validation, nested CV
- Regularisation and tree ensembles

## Planned worked example

Annotated baseline classification pipeline on nutrition data

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
