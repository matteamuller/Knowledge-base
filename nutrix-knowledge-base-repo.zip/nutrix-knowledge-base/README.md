# NUTRIx Knowledge Base

The open-source, version-controlled knowledge base of the **NUTRIx Network
for Computational Nutrition Science**. It turns the network's three thematic
areas into concrete, reusable workflows — annotated notebooks, reproducible
pipelines, and best-practice guides — for early-career nutrition–data
scientists.

> **Status: scaffold.** This repository currently defines the *topic
> structure* across the three research areas plus a cross-cutting
> Foundations section. Each module is a stub with a defined scope; runnable
> content is contributed incrementally via merge requests at network
> Sprint Days.

## Structure

| Area | Folder |
|---|---|
| Dietary Intake & Survival Data | `docs/area-1-diet-survival/` |
| Reproducible & Transparent ML/AI | `docs/area-2-reproducible-ml/` |
| Multi-omics Data Integration | `docs/area-3-multiomics/` |
| Foundations (FAIR, reproducibility, governance) | `docs/foundations/` |

## Build the site locally

```bash
pip install mkdocs-material
mkdocs serve        # http://127.0.0.1:8000
```

A push to `main` builds and deploys the site to GitHub Pages automatically
(see `.github/workflows/deploy.yml`).

## Publish on GitHub

```bash
git init
git add .
git commit -m "Scaffold NUTRIx Knowledge Base (topic structure)"
git branch -M main
git remote add origin https://github.com/<org>/knowledge-base.git
git push -u origin main
```

Then enable **Settings → Pages → Source: GitHub Actions**.

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md). Every module follows the same
template; changes are reviewed by a peer tandem before merge.

## Licence

Code: **MIT** (`LICENSE`). Educational/written content: **CC-BY 4.0**.
Tagged releases are archived to **Zenodo** with a citable DOI.
