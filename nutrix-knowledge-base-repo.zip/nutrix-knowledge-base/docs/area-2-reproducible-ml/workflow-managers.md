---
title: Workflow managers
status: planned
---

# Workflow managers

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- When to move from scripts to a workflow manager
- Snakemake / Nextflow / targets for analysis pipelines

## Planned worked example

Minimal Snakemake workflow for a modelling pipeline

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
