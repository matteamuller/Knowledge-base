---
title: Interpretable / explainable ML
status: planned
---

# Interpretable / explainable ML

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- Global vs local, model-specific vs agnostic taxonomy
- Permutation & conditional importance, SHAP, PDP/ICE/ALE
- Correlated-feature pitfalls (relevant to nutrients)

## Planned worked example

SHAP vs permutation importance under correlated intake variables

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
