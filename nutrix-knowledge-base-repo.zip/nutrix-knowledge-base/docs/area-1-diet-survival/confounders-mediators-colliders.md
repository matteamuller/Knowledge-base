---
title: Confounders, mediators & colliders
status: planned
---

# Confounders, mediators & colliders

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Distinguishing the three structurally
- Why 'adjust for everything' is wrong
- Total vs direct effects

## Planned worked example

Bias demonstration: adjusting for a mediator vs not

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
