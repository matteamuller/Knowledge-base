---
title: Competing risks & time-varying exposures
status: planned
---

# Competing risks & time-varying exposures

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Cause-specific vs subdistribution hazards
- Time-varying covariates and exposures

## Planned worked example

Competing-risks analysis with a non-cardiovascular death risk

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
