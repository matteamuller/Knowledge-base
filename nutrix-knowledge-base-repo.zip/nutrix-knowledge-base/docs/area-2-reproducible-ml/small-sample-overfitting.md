---
title: Small samples & overfitting
status: planned
---

# Small samples & overfitting

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- Why nutrition cohorts are leakage- and overfit-prone
- Sample-size effects on stability
- Class imbalance handling

## Planned worked example

Learning-curve and stability simulation by sample size

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
