---
title: Environments & containers
status: planned
---

# Environments & containers

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- conda / renv pinning
- Docker / Apptainer for analysis reproducibility

## Planned worked example

Container that reproduces a module bit-for-bit

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
