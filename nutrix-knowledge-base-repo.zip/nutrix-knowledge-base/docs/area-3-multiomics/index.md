---
title: Area 3 · Multi-omics Data Integration
---

# Area 3 · Multi-omics Data Integration

Harmonisation and integrative modelling of diet, microbiome, and metabolome.

!!! note "All modules below are planned stubs"
    Scope is defined; content is contributed incrementally.

## Modules

- [Omics data-type primer](omics-data-types.md) — _planned_
- [Microbiome preprocessing](microbiome-preprocessing.md) — _planned_
- [Metabolomics preprocessing](metabolomics-preprocessing.md) — _planned_
- [Batch effects](batch-effects.md) — _planned_
- [Dimensionality reduction](dimensionality-reduction.md) — _planned_
- [Unsupervised integration (MOFA2)](unsupervised-integration-mofa.md) — _planned_
- [Supervised integration (DIABLO)](supervised-integration-diablo.md) — _planned_
- [Differential abundance with covariates](differential-abundance.md) — _planned_
- [Co-occurrence & correlation networks](networks-cooccurrence.md) — _planned_
- [Diet–microbiome–metabolome links](diet-microbiome-metabolome.md) — _planned_
- [Pathway enrichment & interpretation](pathway-enrichment.md) — _planned_
- [Reproducible omics pipelines](reproducible-omics-pipelines.md) — _planned_
