---
title: Feature-selection stability
status: planned
---

# Feature-selection stability

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- Stability metrics across resamples
- Interpreting unstable 'important nutrients'

## Planned worked example

Stability index across bootstrap feature-selection runs

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
