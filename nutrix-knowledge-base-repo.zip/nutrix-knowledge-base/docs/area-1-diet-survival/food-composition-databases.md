---
title: Food composition & branded-food databases
status: planned
---

# Food composition & branded-food databases

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 1 · Dietary Intake & Survival Data._

## Scope

- Mapping reported foods to composition databases
- Branded-food database structure and enrichment
- LLM-supported label parsing pipelines

## Planned worked example

Notebook matching free-text food entries to a composition database

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
