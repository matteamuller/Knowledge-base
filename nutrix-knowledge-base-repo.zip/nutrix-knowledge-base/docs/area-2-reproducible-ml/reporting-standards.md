---
title: Reporting standards & checklists
status: planned
---

# Reporting standards & checklists

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- Domain-specific ML reporting checklist
- Model cards / datasheets for nutrition models

## Planned worked example

Filled reporting checklist for an example study

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
