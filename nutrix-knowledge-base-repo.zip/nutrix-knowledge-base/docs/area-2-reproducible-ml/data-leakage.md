---
title: Avoiding data leakage
status: planned
---

# Avoiding data leakage

!!! note "Status: planned"
    This module is **scaffolded but not yet written**. The outline below defines its intended scope and the worked example it will ship with. Content is added via merge request at network Sprint Days.

_Part of Area 2 · Reproducible & Transparent ML/AI._

## Scope

- Preprocessing, temporal, and group leakage
- Putting transforms inside the CV pipeline

## Planned worked example

Leakage-safe scaling + feature-selection pipeline

## Lead & contributors

_To be assigned at network recruitment / Sprint Day._
