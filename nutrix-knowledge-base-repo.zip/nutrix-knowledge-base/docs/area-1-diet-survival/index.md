---
title: Area 1 · Dietary Intake & Survival Data
---

# Area 1 · Dietary Intake & Survival Data

Dietary assessment data and interpretable survival analysis in nutritional cohorts.

!!! note "All modules below are planned stubs"
    Scope is defined; content is contributed incrementally.

## Modules

- [Dietary data sources & instruments](dietary-data-sources.md) — _planned_
- [Digital & app-based dietary assessment](digital-dietary-assessment.md) — _planned_
- [Food composition & branded-food databases](food-composition-databases.md) — _planned_
- [Preprocessing & harmonisation](dietary-data-preprocessing.md) — _planned_
- [Measurement error & calibration](measurement-error.md) — _planned_
- [Dietary patterns](dietary-patterns.md) — _planned_
- [Causal DAGs](causal-dags.md) — _planned_
- [Confounders, mediators & colliders](confounders-mediators-colliders.md) — _planned_
- [Sensitivity & bias analysis](sensitivity-analysis.md) — _planned_
- [Survival analysis basics](survival-basics.md) — _planned_
- [Cox proportional-hazards models](cox-models.md) — _planned_
- [Competing risks & time-varying exposures](competing-risks-time-varying.md) — _planned_
- [Random survival forests](random-survival-forests.md) — _planned_
- [Interpretable ML for survival](interpretable-ml-survival.md) — _planned_
- [End-to-end cohort workflow](cohort-workflow-example.md) — _planned_
